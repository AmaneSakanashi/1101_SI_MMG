## Requirement
- Python 3.9以下
- Numpy (できれば <= 2.0 )
- Pandas
- Matplotlib
- Scipy
- meson（どうしてもnumpy2.0を使用する場合）



### Compilimg `.f90` files

本シミュレータはPythonのみで機能するが、FortranによりMMGモデルの高速化が可能である。しかし、F2pyの仕様上 `.f90` ファイルのコンパイルをあらかじめ行っておく必要があります。

Esso Osaka (3m)

```bash
gfortran -c shipsim/ship/esso_osaka/f2py_mmg/mmg_esso_osaka_verctor_input.f90
```

```bash
FC=gfortran f2py -m mmg_esso -c --f90flags='-O3' shipsim/ship/esso_osaka/f2py_mmg/mmg_esso_osaka_verctor_input.f90 
```
numpy >= 2.0 を使用する場合は、末尾に
```bash
--backend meson
```




